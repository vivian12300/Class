import Cocoa

var greeting = "Hello, playground"

class carTypes{
    var color: String = "you can choose a wide variety of colors"
    var engines: String = "there are many different types of engines"
    var brand: String = "there are many brands to choose from"
    var size: String = "you can choose the size depending on your needs"
}

var allOptions = carTypes()

var end = allOptions
print("There are many things you need to think about. For example, \(allOptions.color), \(allOptions.engines), \(allOptions.brand), and \(allOptions.size).")
